# Wuddz-Dapp

## Description
- Wuddz-Dapp Is An Awesomely Coded Web3 Decentralized Application In Python, For Everyday Crypto Currency Needs.
  
- Create Accounts, Get All Token Balances & Usd Value For An Account/Wallet, Make Transactions

- Deploy Verify & Interact With Smart Contracts, Swap ERC20 Tokens Using 0x Api, Convert Crypto To Crypto Value

- Get Token Prices In USD, Interact With An Exchange Using Api Authentication & Decode Base64 Encoded Strings.

- I Wrote This Application About A Year Ago At The Height Of The Web3 Craze, 

- I've Seen Way Too Many People Being Scammed & Taken Advantage Of

- All From Visiting Shady Websites Or Using Circumspect Software

- Wuddz-Dapp Is Safe And It Gets The Job Done Period.


## Installation
Install using [PyPI](https://pypi.org/project/wuddz-dapp):
```
$ pip install wuddz-dapp
```
Install locally by cloning or downloading and extracting the repo, then cd into 'dist' directory and execute:
```
$ pip install wuddz_dapp-1.0.2.tar.gz
```
Then to run it, execute the following in the terminal:
```
$ wudz-dapp
```

## Requirements
- python
- ccxt
- pycoingecko
- requests
- setuptools
- web3


## Video:
- https://youtu.be/SjESwOpwh7w


## Contact Info:
- Email:     wuddz_devs@protonmail.com                                                              
- Github:    https://github.com/wuddz-devs                                                          
- Telegram:  https://t.me/wuddz_devs
- Youtube:   https://youtube.com/@wuddz-devs
- Reddit:    https://reddit.com/user/wuddz-devs


### Buy Me A Coffee!!
- ERC20 Address: 0x1F1C47dD653Af628D394eac7bAA9Ccf774fd784f


#### Enjoy my awesome creativity!!
#### Peace & Love Always!!
